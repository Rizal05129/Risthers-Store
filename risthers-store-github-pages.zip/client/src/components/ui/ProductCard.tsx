import { Link } from "wouter";
import { ArrowUpRight, Zap, Eye, Shield } from "lucide-react";
import { type Product, formatRupiah } from "@shared/schema";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";

interface ProductCardProps {
  product: Product;
  index?: number;
}

const categoryIcons = {
  'Drone View': Eye,
  'Damage': Zap,
  'Utility': Shield,
};

export function ProductCard({ product, index = 0 }: ProductCardProps) {
  const Icon = categoryIcons[product.category as keyof typeof categoryIcons] || Shield;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.4 }}
      className="group relative bg-card border border-border rounded-xl overflow-hidden hover:border-primary/50 transition-colors duration-300 flex flex-col h-full"
    >
      <div className="aspect-[4/3] overflow-hidden bg-muted relative">
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent z-10" />
        
        {/* Dynamic Image from DB */}
        <img 
          src={product.imageUrl || ""} 
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110 opacity-80 group-hover:opacity-100"
        />

        <div className="absolute top-4 left-4 z-20">
          <Badge variant="secondary" className="bg-black/50 backdrop-blur border-white/10 text-white">
            <Icon className="w-3 h-3 mr-1" />
            {product.category}
          </Badge>
        </div>

        {product.isPopular && (
          <div className="absolute top-4 right-4 z-20">
            <Badge className="bg-white text-black font-bold">POPULAR</Badge>
          </div>
        )}
      </div>

      <div className="p-6 flex flex-col flex-grow">
        <h3 className="font-display text-xl font-bold mb-2 group-hover:text-primary transition-colors">
          {product.name}
        </h3>
        <p className="text-sm text-muted-foreground mb-6 line-clamp-2 flex-grow">
          {product.description}
        </p>

        <div className="flex items-center justify-between mt-auto">
          <span className="font-display text-lg font-bold">{formatRupiah(product.price)}</span>

          <Link href={`/product/${product.id}`} className="inline-flex items-center text-sm font-semibold hover:text-primary transition-colors">
            View Details <ArrowUpRight className="w-4 h-4 ml-1" />
          </Link>
        </div>
      </div>
    </motion.div>
  );
}

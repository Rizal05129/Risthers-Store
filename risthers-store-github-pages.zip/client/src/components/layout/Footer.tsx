import { Link } from "wouter";
import { ArrowUpRight, MessageCircle } from "lucide-react";
import { WHATSAPP_TESTIMONIAL_URL, WHATSAPP_NUMBER } from "@shared/schema";

const WHATSAPP_ADMIN_URL = `https://wa.me/${WHATSAPP_NUMBER}`;

export function Footer() {
  return (
    <footer className="border-t border-border bg-background py-12 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <Link href="/" className="font-display text-2xl font-bold tracking-tighter">
              RISTHERS<span className="text-muted-foreground">.STORE</span>
            </Link>
            <p className="mt-4 text-muted-foreground max-w-sm">
              Etalase digital yang rapi untuk produk dan bantuan admin melalui WhatsApp.
            </p>
          </div>
          
          <div>
            <h3 className="font-display font-semibold mb-4">Navigasi</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="/products" className="hover:text-foreground">Katalog produk</Link></li>
              <li><Link href="/about" className="hover:text-foreground">Tentang website</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-display font-semibold mb-4">Kontak</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href={WHATSAPP_ADMIN_URL} target="_blank" rel="noreferrer" className="hover:text-foreground inline-flex items-center gap-1">WhatsApp admin <ArrowUpRight className="w-3 h-3" /></a></li>
              <li><a href={WHATSAPP_TESTIMONIAL_URL} target="_blank" rel="noreferrer" className="hover:text-foreground inline-flex items-center gap-1"><MessageCircle className="w-3 h-3" /> Kanal testimoni</a></li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-border flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground">
            © 2026 Risthers Store. Dibuat dengan tampilan hitam-putih yang sederhanakan.
          </p>
          <a href={WHATSAPP_TESTIMONIAL_URL} target="_blank" rel="noreferrer" className="text-sm font-semibold hover:underline underline-offset-4">
            Testimoni di WhatsApp <ArrowUpRight className="inline w-4 h-4 ml-1" />
          </a>
        </div>
      </div>
    </footer>
  );
}

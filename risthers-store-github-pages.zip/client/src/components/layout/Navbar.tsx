import { Link, useLocation } from "wouter";
import { Menu, X, Moon, Sun, MessageCircle } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { WHATSAPP_TESTIMONIAL_URL } from "@shared/schema";

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [location] = useLocation();

  const [isDark, setIsDark] = useState(() => {
    if (typeof window === "undefined") return false;
    return localStorage.getItem("script-store-theme") === "dark";
  });

  useEffect(() => {
    document.documentElement.classList.toggle("dark", isDark);
    localStorage.setItem("script-store-theme", isDark ? "dark" : "light");
  }, [isDark]);

  const navLinks = [
    { href: "/", label: "Beranda" },
    { href: "/products", label: "Katalog" },
    { href: "/about", label: "Tentang" },
  ];

  return (
    <nav className="fixed top-0 w-full z-50 glass border-b border-border/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
            <Link href="/" className="font-display text-xl sm:text-2xl font-bold tracking-tighter">
             RISTHERS<span className="text-muted-foreground">.STORE</span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link 
                key={link.href} 
                href={link.href}
                className={`text-sm font-medium transition-colors hover:text-primary ${
                  location === link.href ? "text-primary" : "text-muted-foreground"
                }`}
              >
                  {link.label}
              </Link>
            ))}
            <a href={WHATSAPP_TESTIMONIAL_URL} target="_blank" rel="noreferrer" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Testimoni
            </a>
            <Button
              variant="ghost"
              size="icon"
              aria-label={isDark ? "Gunakan tema terang" : "Gunakan tema gelap"}
              onClick={() => setIsDark((dark) => !dark)}
            >
              {isDark ? <Sun /> : <Moon />}
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button 
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 text-muted-foreground hover:text-foreground"
            >
              {isOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden border-t border-border bg-background"
          >
            <div className="px-4 py-6 space-y-4">
              {navLinks.map((link) => (
                <Link 
                  key={link.href} 
                  href={link.href}
                  className="block text-lg font-medium text-muted-foreground hover:text-foreground"
                  onClick={() => setIsOpen(false)}
                >
                  {link.label}
                </Link>
              ))}
              <a href={WHATSAPP_TESTIMONIAL_URL} target="_blank" rel="noreferrer" onClick={() => setIsOpen(false)} className="flex items-center gap-2 text-lg font-medium text-muted-foreground hover:text-foreground">
                <MessageCircle className="w-4 h-4" /> Testimoni WhatsApp
              </a>
              <Button variant="outline" className="w-full gap-2" onClick={() => setIsDark((dark) => !dark)}>
                {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
                {isDark ? "Tema terang" : "Tema gelap"}
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}

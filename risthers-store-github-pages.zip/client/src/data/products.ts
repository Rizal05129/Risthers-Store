import { type Product } from "@shared/schema";

// Static product catalog used for static hosting (e.g. GitHub Pages), where there is
// no server/database available. Keep this in sync with server/routes.ts seedDatabase()
// if you also run the full-stack (Express + Postgres) version of this project.

function productImage(name: string) {
  return `https://placehold.co/600x400/000000/FFFFFF/png?font=poppins&text=${encodeURIComponent(name)}`;
}

export const staticProducts: Product[] = [
  {
    id: 1,
    name: "Script Rank Booster",
    description:
      "Script khusus untuk mempercepat progres rank dengan sistem prioritas kemenangan. Aman, Anti Error, Smooth, mendukung pola matchmaking yang lebih ringan sehingga mempermudah proses push rank harian.",
    features: ["Safe", "Anti Error", "Smooth", "Priority Matchmaking", "Push Rank Lebih Cepat", "Work All Tier"],
    requirements: "Wajib menggunakan Mobile Legends versi terbaru (Play Store).",
    category: "Rank Booster",
    notes: "Status: PREMIUM. Membantu mempercepat kenaikan rank, hasil akhir tetap bergantung pada performa tim.",
    imageUrl: productImage("Script Rank Booster"),
    price: 10000,
    isPopular: true,
    createdAt: new Date("2026-01-01"),
  },
  {
    id: 2,
    name: "Script Damage",
    description:
      "Script peningkatan damage untuk skill dan basic attack. Aman, Anti Error, Smooth, cocok untuk hero damage dealer yang membutuhkan dorongan ekstra di pertengahan hingga akhir game.",
    features: ["Safe", "Anti Error", "Smooth", "Damage Boost", "Skill Damage ++", "Work All Tier"],
    requirements: "Wajib menggunakan Mobile Legends versi terbaru (Play Store).",
    category: "Damage",
    notes: "Status: PREMIUM. Cocok untuk hero damage dealer, hasil tetap dipengaruhi build item dan level.",
    imageUrl: productImage("Script Damage"),
    price: 10000,
    isPopular: true,
    createdAt: new Date("2026-01-01"),
  },
  {
    id: 3,
    name: "Script All Fitur",
    description:
      "Paket lengkap gabungan seluruh fitur populer (damage, config anti lag) dalam satu script. Aman, Anti Error, Smooth, ideal untuk pengguna yang ingin pengalaman paling lengkap tanpa install terpisah.",
    features: ["Safe", "Anti Error", "Smooth", "Damage Boost", "Config Anti Lag", "Fast Farming", "Rank Booster", "Semua Fitur Jadi Satu"],
    requirements: "Wajib menggunakan Mobile Legends versi terbaru (Play Store).",
    category: "Premium Bundle",
    notes: "Status: VVIP. Paket paling lengkap, direkomendasikan untuk pengguna baru maupun lama.",
    imageUrl: productImage("Script All Fitur"),
    price: 15000,
    isPopular: true,
    createdAt: new Date("2026-01-01"),
  },
  {
    id: 4,
    name: "Aplikasi Rank Booster",
    description:
      "Aplikasi pendamping (bukan script tambahan di dalam game) untuk membantu strategi push rank, dilengkapi rekomendasi hero, counter pick, dan analisis pola matchmaking. Aman digunakan berdampingan dengan akun utama.",
    features: ["Rekomendasi Hero", "Counter Pick", "Analisis Matchmaking", "Ringan & Mudah Dipakai"],
    requirements: "Kompatibel dengan perangkat Android terbaru.",
    category: "Rank Booster",
    notes: "Status: PREMIUM. Berupa aplikasi terpisah, bukan modifikasi langsung di dalam game.",
    imageUrl: productImage("Aplikasi Rank Booster"),
    price: 20000,
    isPopular: false,
    createdAt: new Date("2026-01-01"),
  },
  {
    id: 5,
    name: "Script Config Atasi Lag",
    description:
      "Config khusus untuk mengurangi lag dan meningkatkan kestabilan koneksi saat bermain. Aman, Anti Error, Ringan, cocok untuk perangkat dengan spesifikasi menengah ke bawah maupun koneksi internet yang kurang stabil.",
    features: ["Anti Lag", "Ringan", "Stabil", "Cocok Perangkat Menengah", "Optimasi Koneksi"],
    requirements: "Wajib menggunakan Mobile Legends versi terbaru (Play Store).",
    category: "Utility",
    notes: "Status: PREMIUM. Membantu mengurangi lag, hasil tetap dipengaruhi kondisi jaringan pengguna.",
    imageUrl: productImage("Script Config Atasi Lag"),
    price: 5000,
    isPopular: false,
    createdAt: new Date("2026-01-01"),
  },
];

import { useQuery } from "@tanstack/react-query";
import { type Product } from "@shared/schema";
import { staticProducts } from "@/data/products";

// This site is built to run fully static (e.g. on GitHub Pages), so product data
// is bundled at build time instead of being fetched from a server/database.
// The useQuery wrapper is kept so components don't need to change (isLoading, etc).

export function useProducts() {
  return useQuery({
    queryKey: ["products"],
    queryFn: async (): Promise<Product[]> => staticProducts,
  });
}

export function useProduct(id: number) {
  return useQuery({
    queryKey: ["products", id],
    queryFn: async (): Promise<Product | null> => {
      return staticProducts.find((p) => p.id === id) ?? null;
    },
    enabled: !!id,
  });
}

import { useProducts } from "@/hooks/use-products";
import { ProductCard } from "@/components/ui/ProductCard";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Loader2 } from "lucide-react";

export default function ProductList() {
  const { data: products, isLoading } = useProducts();
  const [filter, setFilter] = useState<string>("Semua");

  const categories = ["Semua", ...Array.from(new Set(products?.map((product) => product.category) || []))];

  const filteredProducts = filter === "Semua" 
    ? products 
    : products?.filter(p => p.category === filter);

  return (
    <div className="min-h-screen pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-12 text-center md:text-left">
           <p className="eyebrow mb-3">KOLEKSI SCRIPT / 03</p>
           <h1 className="font-display text-4xl md:text-5xl font-bold mb-4">Katalog produk</h1>
          <p className="text-muted-foreground max-w-2xl">
             Lihat koleksi script dan tools yang tersedia. Pilih produk untuk membaca detailnya, lalu hubungi admin melalui WhatsApp.
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap gap-2 mb-12">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`
                px-4 py-2 rounded-full text-sm font-medium transition-all
                ${filter === cat 
                  ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20" 
                  : "bg-card border border-border text-muted-foreground hover:border-primary/50 hover:text-foreground"}
              `}
            >
              {cat}
            </button>
          ))}
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center py-40">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProducts?.map((product, idx) => (
              <ProductCard key={product.id} product={product} index={idx} />
            ))}
            
            {filteredProducts?.length === 0 && (
              <div className="col-span-full text-center py-20 border border-dashed border-border rounded-xl">
                <p className="text-muted-foreground">Belum ada produk di kategori ini.</p>
                <Button variant="ghost" onClick={() => setFilter("Semua")} className="mt-2">
                  Lihat semua produk
                </Button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

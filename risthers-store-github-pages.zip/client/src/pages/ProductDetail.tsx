import { useProduct } from "@/hooks/use-products";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useRoute } from "wouter";
import { Loader2, ArrowLeft, CheckCircle2, AlertTriangle, MessageCircle, Share2, Shield, Check } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { WHATSAPP_NUMBER, formatRupiah } from "@shared/schema";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function ProductDetail() {
  const [, params] = useRoute("/product/:id");
  const id = params ? parseInt(params.id) : 0;
  const { data: product, isLoading, isError } = useProduct(id);
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (isError || !product) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
          <h2 className="text-2xl font-bold mb-4">Produk tidak ditemukan</h2>
        <Link href="/products">
           <Button>Kembali ke katalog</Button>
        </Link>
      </div>
    );
  }

  const handleBuyClick = () => {
    const message = encodeURIComponent(
      `Halo, saya tertarik membeli ${product.name} (${formatRupiah(product.price)}). Apakah masih tersedia?`
    );
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${message}`, '_blank');
  };

  const handleShareClick = async () => {
    const shareUrl = window.location.href;
    try {
      if (navigator.share) {
        await navigator.share({ title: product.name, text: product.description, url: shareUrl });
        return;
      }
    } catch {
      // User cancelled or share failed, fall back to clipboard below
    }
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      toast({ title: "Link disalin", description: "Link produk berhasil disalin ke clipboard." });
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast({ title: "Gagal menyalin link", description: shareUrl, variant: "destructive" });
    }
  };

  const features = product.features || [];

  return (
    <div className="min-h-screen pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Link href="/products" className="inline-flex items-center text-muted-foreground hover:text-foreground mb-8 transition-colors">
          <ArrowLeft className="w-4 h-4 mr-2" /> Kembali ke katalog
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20">
          {/* Left Column: Image */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <div className="aspect-[4/3] rounded-2xl overflow-hidden bg-muted border border-border relative group">
              {/* Dynamic Image from DB */}
              <img 
                src={product.imageUrl || ""} 
                alt={product.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 ring-1 ring-inset ring-white/10 rounded-2xl" />
            </div>

            <div className="p-6 bg-card border border-border rounded-xl">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <Shield className="w-5 h-5 text-primary" />
                Catatan keamanan
              </h3>
              <p className="text-sm text-muted-foreground">
                Pastikan membaca detail dan persyaratan produk sebelum digunakan. Uji kompatibilitas dengan versi game
                terbaru terlebih dahulu.
              </p>
            </div>
          </motion.div>

          {/* Right Column: Details */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex flex-col"
          >
            <div className="mb-6">
              <Badge variant="outline" className="mb-4">{product.category}</Badge>
              <h1 className="font-display text-4xl md:text-5xl font-bold mb-4 tracking-tight">{product.name}</h1>
              <p className="font-display text-2xl md:text-3xl font-bold mb-4">{formatRupiah(product.price)}</p>
              <p className="text-xl text-muted-foreground leading-relaxed">
                {product.description}
              </p>
            </div>

            <div className="h-px w-full bg-border my-8" />

            <div className="space-y-8 mb-10">
              <div>
                <h3 className="text-lg font-semibold mb-4">Fitur utama</h3>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm text-muted-foreground">
                      <CheckCircle2 className="w-5 h-5 text-primary shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {product.requirements && (
                <div>
                    <h3 className="text-lg font-semibold mb-2">Persyaratan</h3>
                  <div className="p-4 bg-muted/50 rounded-lg border border-border text-sm font-mono text-muted-foreground">
                    {product.requirements}
                  </div>
                </div>
              )}

              {product.notes && (
                <div className="flex gap-3 p-4 rounded-lg bg-muted border border-border text-foreground text-sm">
                  <AlertTriangle className="w-5 h-5 shrink-0 text-muted-foreground" />
                  <p>{product.notes}</p>
                </div>
              )}
            </div>

            <div className="mt-auto flex flex-col sm:flex-row gap-4 pt-8 border-t border-border">
              <Button size="lg" className="flex-1 h-14 text-lg gap-2" onClick={handleBuyClick}>
                <MessageCircle className="w-5 h-5" />
                Buy via WhatsApp
              </Button>
              <Button size="lg" variant="outline" className="h-14 w-14 p-0 shrink-0" onClick={handleShareClick} aria-label="Bagikan produk">
                {copied ? <Check className="w-5 h-5" /> : <Share2 className="w-5 h-5" />}
              </Button>
            </div>
             <p className="mt-4 text-center text-xs text-muted-foreground">
               Pengiriman dilakukan setelah konfirmasi pembayaran melalui WhatsApp.
            </p>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

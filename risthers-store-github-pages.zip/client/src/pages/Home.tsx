import { useProducts } from "@/hooks/use-products";
import { ProductCard } from "@/components/ui/ProductCard";
import { Button } from "@/components/ui/button";
import { ArrowRight, Check, ChevronRight, CircleDot, MessageCircle, ShieldCheck, Sparkles } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { WHATSAPP_TESTIMONIAL_URL } from "@shared/schema";

export default function Home() {
  const { data: products, isLoading } = useProducts();
  const featuredProducts = products?.filter((product) => product.isPopular) || [];

  return (
    <div className="min-h-screen">
      <section className="relative overflow-hidden pt-32 pb-20 md:pt-44 md:pb-28">
        <div className="absolute inset-0 grid-pattern opacity-60 pointer-events-none" />
        <div className="hero-glow absolute left-1/2 top-0 -translate-x-1/2 pointer-events-none" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl">
            <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
              <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-mono tracking-wide text-muted-foreground">
                <CircleDot className="w-3.5 h-3.5 text-foreground" />
                RISTHERS STORE / 2026
              </div>
              <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-bold tracking-[-0.06em] leading-[0.96] mt-7 mb-7">
                Mainkan lebih.
                <br />
                <span className="text-muted-foreground">Pilih dengan</span>{" "}
                <span className="text-outline">jelas.</span>
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground max-w-2xl leading-relaxed mb-9">
                Etalase script dan tools MLBB dengan tampilan yang sederhana. Lihat katalog, lalu
                hubungi admin melalui WhatsApp untuk proses pembelian.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <Link href="/products">
                  <Button size="lg" className="h-12 px-6 text-base w-full sm:w-auto">
                    Lihat katalog <ArrowRight className="w-4 h-4" />
                  </Button>
                </Link>
                <a href={WHATSAPP_TESTIMONIAL_URL} target="_blank" rel="noreferrer">
                  <Button variant="outline" size="lg" className="h-12 px-6 text-base w-full sm:w-auto">
                    Hubungi admin
                  </Button>
                </a>
              </div>
            </motion.div>
          </div>

          <div className="mt-20 grid grid-cols-2 md:grid-cols-4 border-y border-border">
            {[
              ["11+", "Produk tersedia"],
              ["100%", "Tampilan responsif"],
              ["24/7", "Bantuan WhatsApp"],
              ["2", "Mode tema"],
            ].map(([value, label]) => (
              <div key={label} className="py-5 pr-4 md:pr-8 first:pl-0 pl-4 md:pl-8 border-l border-border first:border-l-0">
                <p className="font-display text-2xl md:text-3xl font-bold">{value}</p>
                <p className="text-xs uppercase tracking-[0.12em] text-muted-foreground mt-1">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 border-y border-border bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
            <div>
              <p className="eyebrow">KENAPA DI SINI</p>
              <h2 className="font-display text-3xl md:text-4xl font-bold mt-3">Lebih ringkas, lebih mudah.</h2>
            </div>
            <p className="text-muted-foreground max-w-md text-sm leading-relaxed">
              Kami menyusun setiap bagian agar informasi produk dan jalur bantuan bisa ditemukan dalam beberapa klik.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-4">
            {[
              { icon: Sparkles, number: "01", title: "Katalog tertata", text: "Produk dikelompokkan berdasarkan kebutuhan agar kamu tidak perlu mencari terlalu lama." },
              { icon: ShieldCheck, number: "02", title: "Aman & terpercaya", text: "Setiap produk sudah melalui pengecekan sebelum ditampilkan di katalog." },
              { icon: MessageCircle, number: "03", title: "Testimoni terpusat", text: "Testimoni hanya tersedia melalui WhatsApp resmi, tanpa kanal lain yang membingungkan." },
            ].map(({ icon: Icon, number, title, text }) => (
              <div key={number} className="bg-card border border-border rounded-2xl p-6 md:p-7">
                <div className="flex justify-between items-start mb-10">
                  <div className="w-11 h-11 rounded-xl bg-primary text-primary-foreground flex items-center justify-center">
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="font-mono text-xs text-muted-foreground">{number}</span>
                </div>
                <h3 className="font-display text-xl font-bold mb-2">{title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between gap-4 mb-10">
            <div>
              <p className="eyebrow">PILIHAN UTAMA</p>
              <h2 className="font-display text-3xl md:text-4xl font-bold mt-3">Produk populer</h2>
            </div>
            <Link href="/products" className="hidden sm:inline-flex items-center gap-1 text-sm font-semibold hover:underline underline-offset-4">
              Lihat semua <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[1, 2, 3].map((item) => <div key={item} className="h-[390px] rounded-2xl bg-muted animate-pulse" />)}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {featuredProducts.length > 0 ? featuredProducts.map((product, index) => (
                <ProductCard key={product.id} product={product} index={index} />
              )) : <div className="col-span-3 text-center py-20 text-muted-foreground">Belum ada produk populer.</div>}
            </div>
          )}
          <Link href="/products" className="sm:hidden mt-6 flex">
            <Button variant="outline" className="w-full">Lihat semua produk <ArrowRight className="w-4 h-4" /></Button>
          </Link>
        </div>
      </section>

      <section className="pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="rounded-3xl bg-primary text-primary-foreground p-7 md:p-12 relative overflow-hidden">
            <div className="absolute -right-16 -top-20 w-64 h-64 border border-primary-foreground/20 rounded-full" />
            <div className="absolute -right-2 -top-6 w-36 h-36 border border-primary-foreground/20 rounded-full" />
            <div className="relative max-w-2xl">
              <p className="text-xs font-mono tracking-[0.18em] opacity-60 mb-4">TESTIMONI RESMI</p>
              <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">Satu kanal untuk testimoni.</h2>
              <p className="opacity-70 leading-relaxed mb-7">
                Cek pengalaman pengguna lain langsung di WhatsApp. Kami sengaja memusatkan testimoni di satu kanal agar
                informasinya mudah dicek.
              </p>
              <a href={WHATSAPP_TESTIMONIAL_URL} target="_blank" rel="noreferrer">
                <Button variant="secondary" size="lg"><MessageCircle className="w-4 h-4" /> Buka WhatsApp</Button>
              </a>
            </div>
          </div>
        </div>
      </section>

      <section className="pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="border border-border rounded-2xl p-6 md:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div>
              <p className="eyebrow">INFORMASI WEBSITE</p>
              <h2 className="font-display text-2xl font-bold mt-2 mb-2">Kenali cara kerja Risthers Store.</h2>
              <p className="text-sm text-muted-foreground">Baca keterangan pembuatan website dan alur layanan kami.</p>
            </div>
            <Link href="/about">
              <Button variant="outline">Tentang website <ArrowRight className="w-4 h-4" /></Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
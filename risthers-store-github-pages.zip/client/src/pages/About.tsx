import { Link } from "wouter";
import { ArrowRight, Code2, MessageCircle, Palette, Sparkles } from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { WHATSAPP_TESTIMONIAL_URL } from "@shared/schema";

export default function About() {
  return (
    <div className="min-h-screen pt-28 pb-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-3xl"
        >
          <p className="eyebrow">TENTANG WEBSITE / 02</p>
          <h1 className="font-display text-4xl md:text-6xl font-bold tracking-tight mt-4 mb-6">
            Dibuat rapi untuk pengalaman yang sederhana.
          </h1>
          <p className="text-lg md:text-xl leading-relaxed text-muted-foreground">
            Risthers Store adalah etalase digital untuk produk dan layanan MLBB. Semua informasi dibuat ringkas supaya
            pengunjung bisa menemukan produk dan menghubungi admin tanpa alur yang berbelit.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-4 mt-16">
          {[
            { icon: Palette, title: "Visual monochrome", text: "Palet hitam-putih yang bersih, kontras, dan nyaman dibaca." },
            { icon: Code2, title: "Dibangun responsif", text: "Tampilan menyesuaikan desktop, tablet, hingga layar ponsel." },
            { icon: Sparkles, title: "Alur lebih jelas", text: "Katalog dan kontak bantuan berada di tempat yang mudah ditemukan." },
          ].map(({ icon: Icon, title, text }) => (
            <div key={title} className="rounded-2xl border border-border bg-card p-6">
              <div className="w-11 h-11 rounded-xl border border-border flex items-center justify-center mb-6">
                <Icon className="w-5 h-5" />
              </div>
              <h2 className="font-display text-xl font-bold mb-2">{title}</h2>
              <p className="text-sm text-muted-foreground leading-relaxed">{text}</p>
            </div>
          ))}
        </div>

        <div className="mt-16 rounded-3xl bg-primary text-primary-foreground p-7 sm:p-10 flex flex-col md:flex-row justify-between gap-8 items-start md:items-center">
          <div>
            <p className="text-xs font-mono tracking-[0.18em] opacity-60 mb-3">TESTIMONI RESMI</p>
            <h2 className="font-display text-2xl sm:text-3xl font-bold mb-3">Lihat testimoni di WhatsApp</h2>
            <p className="text-sm opacity-70 max-w-xl">
              Testimoni hanya dibagikan melalui kanal WhatsApp resmi agar informasinya tetap terpusat dan mudah diverifikasi.
            </p>
          </div>
          <a href={WHATSAPP_TESTIMONIAL_URL} target="_blank" rel="noreferrer">
            <Button variant="secondary" size="lg" className="whitespace-nowrap">
              <MessageCircle className="w-4 h-4" />
              Buka WhatsApp
            </Button>
          </a>
        </div>

        <div className="mt-12 flex flex-col sm:flex-row gap-3">
          <Link href="/products">
            <Button size="lg">Lihat katalog <ArrowRight className="w-4 h-4" /></Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
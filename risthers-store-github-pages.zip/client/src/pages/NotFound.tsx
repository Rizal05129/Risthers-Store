import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { AlertCircle } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center bg-background text-foreground">
      <div className="flex flex-col items-center gap-4 text-center px-4">
        <AlertCircle className="h-16 w-16 text-destructive opacity-80" />
        <h1 className="text-4xl font-display font-bold">404 Page Not Found</h1>
        <p className="text-muted-foreground max-w-md">
          The page you are looking for doesn't exist or has been moved.
        </p>

        <Link href="/">
          <Button variant="outline" className="mt-4">
            Return Home
          </Button>
        </Link>
      </div>
    </div>
  );
}


import { pgTable, text, serial, boolean, timestamp, jsonb, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  features: jsonb("features").$type<string[]>().default([]),
  requirements: text("requirements"),
  notes: text("notes"),
  category: text("category").notNull(), // 'Drone View', 'Damage', 'Utility', etc.
  imageUrl: text("image_url").default("https://placehold.co/600x400/000000/FFFFFF/png?text=Script+Preview"),
  price: integer("price").notNull().default(0), // price in Indonesian Rupiah (whole number, e.g. 10000)
  isPopular: boolean("is_popular").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertProductSchema = createInsertSchema(products).omit({ 
  id: true, 
  createdAt: true 
});

export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;

export type ProductResponse = Product;
export type ProductsListResponse = Product[];

// For WhatsApp redirection
export const WHATSAPP_NUMBER = "6283167581734"; // This should be configured via env var or admin in real app
export const WHATSAPP_TESTIMONIAL_URL = "https://whatsapp.com/channel/0029Vb7Mesn3rZZm4Mhmhj2K";

// Format a price (in whole Rupiah) as a display string, e.g. 10000 -> "Rp 10.000"
export function formatRupiah(price: number): string {
  return `Rp ${price.toLocaleString("id-ID")}`;
}
